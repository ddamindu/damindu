
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-[#050505] text-white py-32 border-t border-white/5 overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="flex flex-col lg:flex-row justify-between items-start gap-20">
          <div className="max-w-md">
            <h2 className="text-7xl font-display font-extrabold leading-[0.8] mb-8">
              DAMINDU<span className="text-indigo-500">.</span>
            </h2>
            <p className="text-white/30 font-light leading-relaxed">
              Elevating brands through clean aesthetics and technical precision. Based in Sri Lanka, available globally.
            </p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 gap-20">
            <div>
              <span className="text-[10px] uppercase tracking-widest text-indigo-500 font-bold block mb-8">Pages</span>
              <div className="flex flex-col space-y-4">
                <a href="#/" className="text-sm font-bold hover:text-indigo-400 transition-colors">Home</a>
                <a href="#/gallery" className="text-sm font-bold hover:text-indigo-400 transition-colors">Works</a>
                <a href="#/about" className="text-sm font-bold hover:text-indigo-400 transition-colors">About</a>
                <a href="#/contact" className="text-sm font-bold hover:text-indigo-400 transition-colors">Contact</a>
              </div>
            </div>
            <div>
              <span className="text-[10px] uppercase tracking-widest text-indigo-500 font-bold block mb-8">Connect</span>
              <div className="flex flex-col space-y-4">
                <a href="#" className="text-sm font-bold hover:text-indigo-400 transition-colors">LinkedIn</a>
                <a href="#" className="text-sm font-bold hover:text-indigo-400 transition-colors">Behance</a>
                <a href="#" className="text-sm font-bold hover:text-indigo-400 transition-colors">Twitter</a>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-32 pt-12 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-8">
          <span className="text-[10px] uppercase tracking-widest text-white/20 font-bold">
            © {new Date().getFullYear()} Damindu Portfolio • Built for the future
          </span>
          <div className="flex space-x-12">
            <span className="text-[10px] uppercase tracking-widest text-white/20 font-bold">6.9319° N, 79.8478° E</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
