
import React from 'react';

const Hero: React.FC = () => {
  const renderStaggeredText = (text: string, startDelay: number) => {
    return text.split('').map((char, index) => (
      <span
        key={index}
        className="inline-block animate-letter-reveal opacity-0"
        style={{ animationDelay: `${startDelay + index * 0.04}s` }}
      >
        {char === ' ' ? '\u00A0' : char}
      </span>
    ));
  };

  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden bg-[#050505]">
      {/* Dynamic Background Elements */}
      <div className="absolute inset-0 z-0">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-indigo-600/20 rounded-full blur-[120px] animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-cyan-600/10 rounded-full blur-[100px] animate-pulse delay-700"></div>
        <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: 'radial-gradient(circle, #fff 1px, transparent 1px)', backgroundSize: '40px 40px' }}></div>
      </div>

      <div className="container mx-auto px-6 relative z-10 text-center">
        <div className="overflow-hidden mb-4">
          <span className="inline-block text-indigo-500 font-bold uppercase tracking-[0.5em] text-[12px] animate-reveal">
            Graphic Designer • ICT Learner • Sri Lanka
          </span>
        </div>
        
        <h1 className="text-[15vw] lg:text-[12vw] font-display font-extrabold leading-[0.8] mb-12 tracking-tighter">
          <div className="overflow-hidden pb-4">
            {renderStaggeredText("DAMINDU", 0.2)}
          </div>
          <div className="overflow-hidden">
            <span className="text-white/10 outline-text block">
              {renderStaggeredText("PORTFOLIO", 0.6)}
            </span>
          </div>
        </h1>

        <div className="flex flex-col md:flex-row items-center justify-center space-y-6 md:space-y-0 md:space-x-8 animate-reveal delay-1000 opacity-0 fill-mode-forwards">
          <a 
            href="#/gallery" 
            className="group relative px-12 py-5 overflow-hidden rounded-full border border-white/20 transition-all hover:border-indigo-500"
          >
            <div className="absolute inset-0 bg-indigo-500 translate-y-full group-hover:translate-y-0 transition-transform duration-500"></div>
            <span className="relative text-[11px] font-bold uppercase tracking-[0.2em] group-hover:text-white transition-colors">
              Explore Projects
            </span>
          </a>
          <a 
            href="#/about" 
            className="text-[11px] font-bold uppercase tracking-[0.2em] border-b-2 border-white/20 hover:border-indigo-500 transition-all pb-1"
          >
            The Journey
          </a>
        </div>
      </div>

      {/* Side Label */}
      <div className="absolute left-10 bottom-10 hidden lg:block rotate-[-90deg] origin-left">
        <span className="text-[10px] uppercase tracking-[0.4em] font-bold text-white/30">Based in South Asia</span>
      </div>

      <style>{`
        .outline-text {
          -webkit-text-stroke: 1px rgba(255, 255, 255, 0.2);
          text-shadow: none;
        }
        @keyframes heroReveal {
          from { transform: translateY(100px); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }
        @keyframes letterReveal {
          0% {
            transform: translateY(110%);
            opacity: 0;
          }
          100% {
            transform: translateY(0);
            opacity: 1;
          }
        }
        .animate-reveal { 
          animation: heroReveal 1s cubic-bezier(0.16, 1, 0.3, 1) forwards; 
        }
        .animate-letter-reveal {
          animation: letterReveal 1.2s cubic-bezier(0.16, 1, 0.3, 1) forwards;
        }
        .fill-mode-forwards { animation-fill-mode: forwards; }
        .delay-1000 { animation-delay: 1s; }
      `}</style>
    </section>
  );
};

export default Hero;
