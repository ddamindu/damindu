
import React, { useState } from 'react';
import { getDesignAdvice } from '../services/gemini';

const DesignAssistant: React.FC = () => {
  const [pref, setPref] = useState('');
  const [result, setResult] = useState<{advice: string, steps: string[]} | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pref) return;
    setLoading(true);
    const data = await getDesignAdvice(pref);
    setResult(data);
    setLoading(false);
  };

  return (
    <section className="py-32 bg-[#0a0a0a] border-y border-white/5 overflow-hidden">
      <div className="container mx-auto px-6 relative">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-5xl md:text-7xl font-display font-extrabold mb-8">AI VISIONARY.</h2>
            <p className="text-white/40 text-lg font-light">Collaborate with Damindu's virtual design strategy assistant.</p>
          </div>

          <form onSubmit={handleSubmit} className="relative group">
            <input 
              type="text" 
              value={pref}
              onChange={(e) => setPref(e.target.value)}
              placeholder="YOUR PROJECT GOAL..."
              className="w-full bg-transparent border-b-2 border-white/10 py-10 text-3xl md:text-5xl font-display font-bold uppercase placeholder:text-white/5 focus:outline-none focus:border-indigo-500 transition-all text-center"
            />
            <button 
              type="submit" 
              disabled={loading}
              className="absolute right-0 bottom-4 px-10 py-4 bg-indigo-600 rounded-full text-[11px] font-bold uppercase tracking-widest hover:scale-110 active:scale-95 disabled:opacity-50 transition-all"
            >
              {loading ? 'ANALYZING...' : 'GET ADVICE'}
            </button>
          </form>

          {result && (
            <div className="mt-20 space-y-20 animate-fade-in">
              <div className="text-center max-w-2xl mx-auto">
                <p className="text-3xl font-display font-bold text-indigo-400 italic">
                  "{result.advice}"
                </p>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-px bg-white/5 border border-white/5">
                {result.steps.map((step, i) => (
                  <div key={i} className="bg-black p-12 hover:bg-white/5 transition-colors">
                    <span className="text-[10px] text-white/30 font-bold block mb-8">PHASE 0{i+1}</span>
                    <p className="text-sm text-white/80 leading-relaxed font-light">{step}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
      <style>{`
        .animate-fade-in { animation: fadeIn 1.2s cubic-bezier(0.16, 1, 0.3, 1) forwards; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: translateY(0); } }
      `}</style>
    </section>
  );
};

export default DesignAssistant;
