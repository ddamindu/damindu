
import React from 'react';

const About: React.FC = () => {
  return (
    <div className="pt-32 pb-40 px-6 bg-[#050505]">
      <div className="container mx-auto">
        {/* Giant Headings */}
        <div className="mb-32">
          <h1 className="text-7xl md:text-[12vw] font-display font-extrabold leading-[0.8] mb-0 tracking-tighter">
            DAMINDU<br /><span className="text-indigo-500">DOSSIER</span><br />24/25.
          </h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          <div className="lg:col-span-5">
            <div className="sticky top-40 space-y-12">
              <div className="aspect-[4/5] bg-white/5 rounded-2xl overflow-hidden relative group">
                <img 
                  src="https://images.unsplash.com/photo-1558655146-d09347e92766?auto=format&fit=crop&q=80&w=1200" 
                  alt="Damindu Professional" 
                  className="w-full h-full object-cover grayscale mix-blend-luminosity brightness-75 group-hover:scale-110 transition-transform duration-1000"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-indigo-500/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
              </div>
              <div className="p-8 border border-white/10 rounded-2xl bg-white/5 hover:border-indigo-500/50 transition-colors">
                <span className="text-[10px] font-bold uppercase tracking-[0.5em] text-indigo-500 mb-6 block">Current Role</span>
                <p className="text-white font-display font-bold text-2xl leading-tight">Visual Communication Lead & ICT Scholar.</p>
              </div>
            </div>
          </div>

          <div className="lg:col-span-7 space-y-32">
            {/* Professional Bio */}
            <div className="max-w-2xl">
              <span className="text-indigo-500 font-bold uppercase tracking-[0.3em] text-[12px] mb-8 block">Background</span>
              <p className="text-4xl font-display font-bold text-white mb-12 leading-tight uppercase tracking-tight">
                Synthesizing Creative Aesthetics with Data-Driven ICT Logic.
              </p>
              <div className="space-y-8 text-xl text-white/50 font-light leading-relaxed">
                <p>
                  Damindu is a high-performance Graphic Designer and Information Communication Technology (ICT) scholar based in Sri Lanka. He specializes in creating scalable brand architectures and digital ecosystems that balance high-end aesthetic value with functional efficiency.
                </p>
                <p>
                  His methodology is informed by his ongoing ICT studies, allowing him to approach design not just as a visual exercise, but as a strategic component of a larger digital infrastructure. This intersection of skills makes him uniquely capable of collaborating with both marketing teams and technical departments.
                </p>
                <p>
                  From his studio in Colombo, Damindu serves a diverse portfolio of international clients, providing expertise in visual identity, social media narrative, and user interface systems. He is a proponent of AI-augmented design workflows, constantly pushing the boundaries of creative output speed without compromising on quality.
                </p>
              </div>
            </div>

            {/* Experience Timeline */}
            <div className="space-y-12">
              <span className="text-indigo-500 font-bold uppercase tracking-[0.3em] text-[12px] block">Professional Milestones</span>
              <div className="space-y-8">
                {[
                  { date: '2023 - PRESENT', role: 'Freelance Visual Designer', company: 'Global Freelance Network' },
                  { date: '2022 - PRESENT', role: 'ICT Degree Program', company: 'National Institute of Tech' },
                  { date: '2021 - 2023', role: 'Social Media Content Lead', company: 'Regional Creative Agency' }
                ].map((item, idx) => (
                  <div key={idx} className="flex flex-col md:flex-row md:items-center justify-between py-8 border-b border-white/5 group hover:pl-4 transition-all duration-500">
                    <span className="text-[10px] font-bold uppercase tracking-widest text-indigo-500 mb-2 md:mb-0">{item.date}</span>
                    <h4 className="text-xl font-display font-bold text-white">{item.role}</h4>
                    <span className="text-white/30 text-sm font-light uppercase tracking-widest">{item.company}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Technical Skills Overlay */}
            <div className="space-y-12">
              <span className="text-indigo-500 font-bold uppercase tracking-[0.3em] text-[12px] block">Skill Inventory</span>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-8">
                {['Brand Systems', 'UI/UX Prototyping', 'Content Strategy', 'Typography', 'AI Workflows', 'Frontend Dev', 'Motion Graphics', 'Market Research'].map((skill, i) => (
                  <div key={i} className="p-6 border border-white/5 rounded-xl hover:border-indigo-500 transition-colors">
                    <p className="text-sm font-bold uppercase tracking-widest text-white/70">{skill}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Quote Block */}
            <div className="bg-white p-16 rounded-3xl relative group overflow-hidden">
               <div className="absolute top-0 right-0 p-8 opacity-5 font-display font-black text-9xl text-black">SRI</div>
               <p className="text-black text-3xl font-display font-bold leading-tight relative z-10 italic">
                 "Design is the bridge between human needs and technical capabilities. My goal is to make that bridge beautiful and effortless."
               </p>
               <div className="mt-12 flex items-center space-x-4 relative z-10">
                  <div className="w-12 h-px bg-indigo-600"></div>
                  <span className="text-[10px] uppercase tracking-widest font-bold text-black/60">DAMINDU | Portfolio 2025</span>
               </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
