
import React, { useState } from 'react';

const Contact: React.FC = () => {
  const [formState, setFormState] = useState({ name: '', email: '', message: '' });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setFormState({ name: '', email: '', message: '' });
  };

  return (
    <div className="pt-32 pb-40 px-6 bg-[#050505] min-h-screen">
      <div className="container mx-auto">
        <header className="mb-32">
          <span className="text-indigo-500 font-bold uppercase tracking-[0.4em] text-[10px] mb-4 block">Connections</span>
          <h1 className="text-7xl md:text-[12vw] font-display font-extrabold leading-[0.8] mb-0 tracking-tighter">
            TALK<br />SOON.
          </h1>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-24 items-start">
          <div className="lg:col-span-5 space-y-16">
            <p className="text-3xl font-display font-bold text-white leading-tight">
              Looking for a partner in design? I'm currently open to new collaborations.
            </p>
            
            <div className="space-y-10">
              <div>
                <span className="text-[10px] uppercase tracking-widest text-indigo-500 font-bold block mb-4">Direct Email</span>
                <a href="mailto:hello@damindu.design" className="text-2xl font-display font-bold hover:text-indigo-400 transition-colors">hello@damindu.design</a>
              </div>
              <div>
                <span className="text-[10px] uppercase tracking-widest text-indigo-500 font-bold block mb-4">Social Presence</span>
                <div className="flex space-x-8">
                  {['LinkedIn', 'Behance', 'Instagram'].map(item => (
                    <a key={item} href="#" className="font-display font-bold text-lg hover:text-indigo-400 transition-colors">{item}</a>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-7 bg-white/5 p-12 rounded-2xl border border-white/5">
            {submitted ? (
              <div className="py-20 text-center">
                <div className="text-8xl mb-12">🚀</div>
                <h2 className="text-4xl font-display font-extrabold mb-4">TRANSMISSION SENT.</h2>
                <p className="text-white/40 font-light">I'll get back to you within one business day.</p>
                <button 
                  onClick={() => setSubmitted(false)}
                  className="mt-12 text-[11px] font-bold uppercase tracking-widest text-indigo-500"
                >
                  Send Another One
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-12">
                <div className="group">
                  <label className="text-[10px] font-bold uppercase tracking-widest text-white/30 group-focus-within:text-indigo-500 transition-colors mb-4 block">Your Identity</label>
                  <input 
                    required
                    type="text" 
                    value={formState.name}
                    onChange={(e) => setFormState({...formState, name: e.target.value})}
                    placeholder="NAME / COMPANY"
                    className="w-full bg-transparent border-b border-white/10 py-6 text-2xl font-display font-bold placeholder:text-white/5 focus:outline-none focus:border-indigo-500 transition-all"
                  />
                </div>
                <div className="group">
                  <label className="text-[10px] font-bold uppercase tracking-widest text-white/30 group-focus-within:text-indigo-500 transition-colors mb-4 block">Reach Back</label>
                  <input 
                    required
                    type="email" 
                    value={formState.email}
                    onChange={(e) => setFormState({...formState, email: e.target.value})}
                    placeholder="EMAIL ADDRESS"
                    className="w-full bg-transparent border-b border-white/10 py-6 text-2xl font-display font-bold placeholder:text-white/5 focus:outline-none focus:border-indigo-500 transition-all"
                  />
                </div>
                <div className="group">
                  <label className="text-[10px] font-bold uppercase tracking-widest text-white/30 group-focus-within:text-indigo-500 transition-colors mb-4 block">The Mission</label>
                  <textarea 
                    required
                    rows={4}
                    value={formState.message}
                    onChange={(e) => setFormState({...formState, message: e.target.value})}
                    placeholder="TELL ME EVERYTHING..."
                    className="w-full bg-transparent border-b border-white/10 py-6 text-2xl font-display font-bold placeholder:text-white/5 focus:outline-none focus:border-indigo-500 transition-all resize-none"
                  ></textarea>
                </div>
                <button 
                  type="submit"
                  className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-8 rounded-xl font-display font-extrabold text-2xl uppercase tracking-tighter hover:scale-105 transition-all shadow-2xl"
                >
                  SEND MESSAGE
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
