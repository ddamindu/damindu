
import React, { useState, useEffect } from 'react';
import { GALLERY_IMAGES, EnhancedGalleryImage } from '../constants';

const Gallery: React.FC = () => {
  const [filter, setFilter] = useState<'all' | 'branding' | 'social-media' | 'web-ui'>('all');
  const [selectedProject, setSelectedProject] = useState<EnhancedGalleryImage | null>(null);

  const filteredImages = filter === 'all' 
    ? GALLERY_IMAGES 
    : GALLERY_IMAGES.filter(img => img.category === filter);

  const closeProject = () => {
    setSelectedProject(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (selectedProject) {
    return (
      <div className="min-h-screen bg-[#050505] pt-32 pb-40 px-6 animate-fade-in">
        <div className="container mx-auto">
          {/* Professional Header */}
          <div className="flex justify-between items-center mb-20">
            <button 
              onClick={closeProject}
              className="group flex items-center space-x-4 text-indigo-500 font-bold uppercase tracking-[0.3em] text-[12px]"
            >
              <span className="w-12 h-px bg-indigo-500 group-hover:w-20 transition-all"></span>
              <span>All Works</span>
            </button>
            <span className="text-white/20 font-bold uppercase tracking-[0.4em] text-[10px] hidden md:block">
              Case Study / {selectedProject.id.padStart(2, '0')}
            </span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-20 items-start">
            {/* Visuals Content */}
            <div className="lg:col-span-8 space-y-12">
              <div className="aspect-[16/9] bg-white/5 rounded-3xl overflow-hidden shadow-2xl">
                <img 
                  src={selectedProject.url} 
                  alt={selectedProject.title} 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="grid grid-cols-2 gap-8">
                 <div className="aspect-square bg-white/5 rounded-2xl overflow-hidden opacity-50">
                    <img src={selectedProject.url} className="w-full h-full object-cover grayscale" />
                 </div>
                 <div className="aspect-square bg-indigo-600 rounded-2xl flex items-center justify-center p-8 text-center">
                    <p className="text-white font-display font-bold text-2xl uppercase tracking-tighter">Deliverable Focus</p>
                 </div>
              </div>
            </div>

            {/* Professional Meta Sidebar */}
            <div className="lg:col-span-4 space-y-16">
              <div>
                <span className="text-indigo-500 font-bold uppercase tracking-[0.4em] text-[10px] mb-4 block">Project Title</span>
                <h1 className="text-5xl font-display font-extrabold text-white mb-6 uppercase tracking-tighter">
                  {selectedProject.title}
                </h1>
                <p className="text-white/40 text-lg font-light leading-relaxed italic">
                  "{selectedProject.description}"
                </p>
              </div>

              <div className="space-y-10">
                <div className="space-y-4">
                  <span className="text-[10px] uppercase tracking-widest text-indigo-500 font-bold">The Challenge</span>
                  <p className="text-white/60 font-light leading-relaxed">
                    {selectedProject.longDescription}
                  </p>
                </div>

                <div className="space-y-4">
                  <span className="text-[10px] uppercase tracking-widest text-indigo-500 font-bold">Deliverables</span>
                  <div className="flex flex-wrap gap-2">
                    {selectedProject.deliverables.map((d, i) => (
                      <span key={i} className="px-4 py-2 border border-white/10 rounded-full text-[10px] font-bold text-white/50 uppercase tracking-widest">{d}</span>
                    ))}
                  </div>
                </div>

                <div className="pt-10 border-t border-white/10">
                   {selectedProject.projectUrl && (
                    <a 
                      href={selectedProject.projectUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full block text-center py-5 bg-white text-black rounded-xl font-bold uppercase tracking-widest text-[11px] hover:bg-indigo-500 hover:text-white transition-all shadow-xl"
                    >
                      View Live Project
                    </a>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
        <style>{`
          .animate-fade-in { animation: fadeIn 0.8s cubic-bezier(0.16, 1, 0.3, 1) forwards; }
          @keyframes fadeIn { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
        `}</style>
      </div>
    );
  }

  return (
    <div className="pt-32 pb-40 px-6 bg-[#050505] min-h-screen">
      <div className="container mx-auto">
        <header className="mb-32 flex flex-col md:flex-row md:items-end justify-between gap-12">
          <div>
            <span className="text-indigo-500 font-bold uppercase tracking-[0.4em] text-[10px] mb-4 block">Professional Archive</span>
            <h1 className="text-7xl md:text-[10vw] font-display font-extrabold leading-[0.8] mb-0 tracking-tighter uppercase">Selected Works.</h1>
          </div>
          <div className="flex flex-wrap gap-8">
            {['all', 'branding', 'social-media', 'web-ui'].map((cat) => (
              <button
                key={cat}
                onClick={() => setFilter(cat as any)}
                className={`text-[11px] font-bold uppercase tracking-[0.2em] transition-all relative ${
                  filter === cat 
                    ? 'text-white' 
                    : 'text-white/30 hover:text-white/60'
                }`}
              >
                {cat.replace('-', ' ')}
                {filter === cat && <div className="absolute -bottom-2 left-0 w-full h-1 bg-indigo-500"></div>}
              </button>
            ))}
          </div>
        </header>

        {/* High Impact Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-white/5 border border-white/5">
          {filteredImages.map((project, i) => (
            <button 
              key={project.id} 
              onClick={() => {
                setSelectedProject(project);
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className={`group relative overflow-hidden bg-[#0a0a0a] text-left outline-none ${i % 3 === 0 ? 'md:col-span-2' : ''}`}
            >
              <div className="aspect-video lg:aspect-square xl:aspect-[16/7] relative overflow-hidden">
                <img 
                  src={project.url} 
                  alt={project.title} 
                  className="w-full h-full object-cover transition-transform duration-1000 scale-105 group-hover:scale-110 grayscale group-hover:grayscale-0 opacity-40 group-hover:opacity-100"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-80 group-hover:opacity-40 transition-opacity"></div>
                
                <div className="absolute inset-0 p-12 flex flex-col justify-end">
                  <span className="text-indigo-500 font-bold uppercase tracking-widest text-[10px] mb-4 translate-y-8 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-500">
                    {project.category.replace('-', ' ')}
                  </span>
                  <h3 className="text-4xl md:text-6xl font-display font-extrabold text-white translate-y-8 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-700 delay-100 uppercase">
                    {project.title}
                  </h3>
                  <p className="max-w-md text-white/50 font-light mt-4 translate-y-8 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-700 delay-200">
                    {project.description}
                  </p>
                </div>

                <div className="absolute top-12 right-12 w-16 h-16 border border-white/20 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-500 hover:bg-white hover:text-black">
                   <span className="text-[10px] font-bold uppercase tracking-widest">View Detail</span>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Gallery;
