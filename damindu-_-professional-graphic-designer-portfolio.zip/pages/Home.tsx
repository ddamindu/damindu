
import React from 'react';
import Hero from '../components/Hero';
import DesignAssistant from '../components/LifestyleAssistant';

const Home: React.FC = () => {
  return (
    <div className="flex flex-col bg-[#050505]">
      <Hero />
      
      {/* Manifesto Section */}
      <section className="py-48 px-6 container mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          <div className="lg:col-span-8">
            <span className="text-indigo-500 font-bold uppercase tracking-[0.4em] text-[10px] mb-12 block">Strategic Approach</span>
            <h2 className="text-6xl md:text-9xl font-display font-extrabold leading-[0.85] mb-12 tracking-tighter uppercase">
              DESIGN <br />
              MEETS <br />
              <span className="text-indigo-500">PRECISION.</span>
            </h2>
          </div>
          <div className="lg:col-span-4 lg:pt-32">
            <p className="text-white/60 text-xl md:text-2xl font-light leading-relaxed">
              Damindu combines aesthetic intuition with the technical rigor of an ICT education. Based in Sri Lanka, delivering global-standard visual systems and digital strategies.
            </p>
          </div>
        </div>
      </section>

      {/* Expertise Grid */}
      <section className="py-32 border-y border-white/5">
        <div className="container mx-auto px-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4">
          {[
            { title: 'Identity', accent: 'ID', desc: 'Crafting unique brand signals that cut through the noise of modern markets.' },
            { title: 'UX Design', accent: 'UX', desc: 'Developing human-centric flows informed by ICT principles and user psychology.' },
            { title: 'Narrative', accent: 'ST', desc: 'Translating complex brand messages into compelling social media narratives.' },
            { title: 'Automation', accent: 'AI', desc: 'Utilizing AI-driven workflows to accelerate creativity and design efficiency.' }
          ].map((item, i) => (
            <div key={i} className="group border-r border-white/5 last:border-0 p-16 hover:bg-white/5 transition-all duration-700">
              <span className="text-indigo-500 text-6xl font-display font-extrabold block mb-12 opacity-10 group-hover:opacity-100 group-hover:translate-x-4 transition-all duration-700">
                {item.accent}
              </span>
              <h3 className="text-2xl font-display font-bold mb-6 group-hover:text-indigo-500 transition-colors uppercase tracking-tight">
                {item.title}
              </h3>
              <p className="text-sm text-white/40 font-light leading-relaxed opacity-0 group-hover:opacity-100 transition-opacity duration-700 delay-100">
                {item.desc}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Process Section */}
      <section className="py-48 bg-white/5 border-b border-white/5 overflow-hidden relative">
        <div className="container mx-auto px-6">
          <header className="mb-24 flex flex-col md:flex-row items-end justify-between">
            <h2 className="text-5xl md:text-7xl font-display font-extrabold text-white tracking-tighter uppercase">Workflow<br />Process.</h2>
            <p className="text-indigo-500 font-bold uppercase tracking-widest text-[11px] mb-4">How I collaborate with clients</p>
          </header>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {[
              { step: '01', title: 'Discovery', desc: 'Deep-diving into your brand DNA, market positioning, and core objectives.' },
              { step: '02', title: 'Strategy', desc: 'Defining the visual roadmap and technical requirements for the project.' },
              { step: '03', title: 'Execution', desc: 'Iterative design and development with high-fidelity prototyping and feedback.' }
            ].map((item, idx) => (
              <div key={idx} className="relative group p-12 bg-black border border-white/10 rounded-3xl hover:border-indigo-500 transition-all duration-500">
                <span className="text-indigo-500 font-display font-black text-7xl opacity-20 group-hover:opacity-100 transition-opacity mb-8 block">{item.step}</span>
                <h4 className="text-2xl font-display font-bold mb-6 text-white">{item.title}</h4>
                <p className="text-white/40 font-light text-sm leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <DesignAssistant />

      {/* CTA */}
      <section className="py-64 bg-indigo-600 flex flex-col items-center justify-center text-center px-6 overflow-hidden relative group">
        <div className="absolute inset-0 opacity-10 font-display font-black text-[30vw] whitespace-nowrap select-none pointer-events-none -translate-x-1/4 group-hover:translate-x-0 transition-transform duration-[15s] ease-linear">
          ELEVATE BRANDS ELEVATE BRANDS ELEVATE BRANDS
        </div>
        <div className="relative z-10 max-w-4xl">
           <span className="text-white font-bold uppercase tracking-[0.5em] text-[12px] mb-8 block">Project Inquiry</span>
           <h2 className="text-6xl md:text-[8vw] font-display font-extrabold text-white mb-16 leading-none tracking-tighter uppercase">
             READY TO <br />TRANSFORM?
           </h2>
           <a 
            href="#/contact" 
            className="inline-block px-16 py-6 bg-white text-indigo-600 font-bold uppercase tracking-widest text-[14px] rounded-full hover:bg-black hover:text-white transition-all hover:scale-110 shadow-2xl"
          >
            Start a Conversation
          </a>
        </div>
      </section>
    </div>
  );
};

export default Home;
