
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getDesignAdvice = async (userPrompt: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `You are Damindu's Design Assistant. Damindu is a Graphic Designer and ICT learner. 
      A potential client/visitor asked: "${userPrompt}". 
      Provide a professional, creative, and encouraging response (2-3 sentences) suggesting how Damindu could help them with their design or tech project. 
      Also provide 3 specific creative 'Action Steps'. Respond in JSON format with fields: 'advice' (string) and 'steps' (array of strings).`,
      config: {
        responseMimeType: "application/json",
      }
    });
    
    return JSON.parse(response.text || '{}');
  } catch (error) {
    console.error("Gemini Error:", error);
    return {
      advice: "That sounds like a fantastic project! Damindu specializes in blending clean aesthetics with functional design to bring such ideas to life.",
      steps: ["Define your brand's core visual message", "Create a moodboard of styles you love", "Schedule a quick virtual coffee with Damindu"]
    };
  }
};
